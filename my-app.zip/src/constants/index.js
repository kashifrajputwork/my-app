export const ROUTES = {
    login: "/",
    forgot_password:"/forgot-password",
    recover_password:'/recover-password',
    dashboard:'/dashboard'
};