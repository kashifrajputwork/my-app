import React from "react";

const BettingReport = () => {
  return (
    <div>
        Hi
    </div>
  );
};

export default BettingReport;